var express = require('express');
var path = require('path');
var fs = require('fs');
var app = express();
var sql = require('mssql/msnodesqlv8');
const { query } = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
var alert = require('alert');

var allUpcomingMatchesRouter = require('./routes/allUpcomingMatches');
var playedMatchesRouter = require('./routes/playedMatches');
var clubsNeverMatchedRouter = require('./routes/clubsNeverMatched');
var clubInfoRouter = require('./routes/clubInfo');
var stadiumInfoRouter = require('./routes/stadiumInfo');
var upcomingMatchesOfClubRouter = require('./routes/upcomingMatchesOfClub');
var availableStadiumsOnRouter = require('./routes/availableStadiumsOn');
var allSentRequestsRouter = require('./routes/allSentRequests');
var availableMatchesToAttendRouter = require('./routes/availableMatchesToAttend')
// database configuration
var config={
  database: 'Milestone2',
  server: 'JOY-LENOVO\\SQLEXPRESS',
  driver: 'msnodesqlv8',
  options:{
    trustedConnection:true
  }
};


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/allUpcomingMatches', allUpcomingMatchesRouter);
app.use('/playedMatches', playedMatchesRouter);
app.use('/clubsNeverMatched', clubsNeverMatchedRouter);
app.use('/clubInfo', clubInfoRouter);
app.use('/stadiumInfo', stadiumInfoRouter);
app.use('/upcomingMatchesOfClub', upcomingMatchesOfClubRouter);
app.use('/availableStadiumsOn', availableStadiumsOnRouter);
app.use('/allSentRequests', allSentRequestsRouter);
app.use('/availableMatchesToAttend', availableMatchesToAttendRouter);
app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));

app.get('/home', function(req, res){
  res.render('home')
});

app.get('/Login', function(req, res){
  res.render('Login')
});

app.get('/Registration', function(req, res){
  res.render('Registration')
});

app.get('/ClubRepresentative', function(req, res){
  res.render('ClubRepresentative')
});
app.get('/SystemAdminLog', function(req, res){
  res.render('SystemAdminLog')
});
/*app.get('/SystemAdminReg', function(req, res){
  res.render('SystemAdminReg')
});*/
app.get('/StadiumManagerLog', function(req, res){
  res.render('StadiumManagerLog')
});
app.get('/StadiumManagerReg', function(req, res){
  res.render('StadiumManagerReg')
});
app.get('/SportsAssociationManagerLog', function(req, res){
  res.render('SportsAssociationManagerLog')
});
app.get('/SportsAssociationManagerReg', function(req, res){
  res.render('SportsAssociationManagerReg')
});
app.get('/FanLog', function(req, res){
  res.render('FanLog')
});
app.get('/FanReg', function(req, res){
  res.render('FanReg')
});
app.get('/ClubRepresentativeLog', function(req, res){
  res.render('ClubRepresentativeLog')
});
app.get('/ClubRepresentativeReg', function(req, res){
  res.render('ClubRepresentativeReg')
});
app.get('/StadiumManager', function(req, res){
  res.render('StadiumManager')
});
app.get('/Fan', function(req, res){
  res.render('Fan')
});



app.post('/SystemAdminLog', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (username && password) {
      let query = "SELECT * FROM SystemUser SU,SystemAdmin SA WHERE SU.username = '" + username + "' AND SU.password = '" + password + "' AND SA.username = SU.username;";
      console.log(query)
      request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length > 0) {
          res.redirect('/SystemAdmin');
          }
          else{
            alert('Incorrect Username and/or Password!');
          }
          sql.close();
      });
    } else {
      alert('Please enter your username and password!');
      sql.close();
    };
  });
});

app.post('/ClubRepresentativeLog', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (username && password) {
      let query = "SELECT * FROM SystemUser SU,ClubRepresentative SA WHERE SU.username = '" + username + "' AND SU.password = '" + password + "' AND SA.username = SU.username;";
      console.log(query)
      request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length > 0) {
          res.redirect('/ClubRepresentative');
          }
          else{
            alert('Incorrect Username and/or Password!');
          }
          sql.close();
      });
    } else {
      alert('Please enter your username and password!');
      sql.close();
    };
  });
});

app.post('/FanLog', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (username && password) {
      let query = "SELECT * FROM SystemUser SU,Fan SA WHERE SU.username = '" + username + "' AND SU.password = '" + password + "' AND SA.username = SU.username;";
      console.log(query)
      request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length > 0) {
            let query1 = "SELECT * FROM allFans WHERE username = '" + username + "' AND password = '" + password + "' AND status = '1' ;";
            request.query(query1, function (err, result) {
              if (err) {
                  console.log(err);
                  sql.close();
              }
              if (result.recordset.length > 0) {
                res.redirect('/Fan');
                sql.close();
              }
              else{
              alert('You can not login into the system because you are blocked!');
              sql.close();
              }
            });
          }
          else{
            alert('Incorrect Username and/or Password!');
            sql.close();
          }
      });
    } else {
      alert('Please enter your username and password!');
      sql.close();
    };
  });
});

app.post('/SportsAssociationManagerLog', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (username && password) {
      let query = "SELECT * FROM SystemUser SU, SportsAssociationManager SA WHERE SU.username = '" + username + "' AND SU.password = '" + password + "' AND SA.username = SU.username;";
      console.log(query)
      request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length > 0) {
          res.redirect('/SportsAssociationManager');
          }
          else{
            alert('Incorrect Username and/or Password!');
          }
          sql.close();
      });
    } else {
      alert('Please enter your username and password!');
      sql.close();
    };
  });
});

app.post('/StadiumManagerLog', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (username && password) {
      let query = "SELECT * FROM SystemUser SU, StadiumManager SA WHERE SU.username = '" + username + "' AND SU.password = '" + password + "' AND SA.username = SU.username;";
      console.log(query)
      request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length > 0) {
          res.redirect('/StadiumManager');
          }
          else{
            alert('Incorrect Username and/or Password!');
          }
          sql.close();
      });
    } else {
      alert('Please enter your username and password!');
      sql.close();
    };
  });
});

app.post('/StadiumManagerReg', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  var name = req.body.name;
  var stadiumName = req.body.stadiumName;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (username && password && name && stadiumName) {
        let query2 = "SELECT * FROM SystemUser WHERE username = '" + username + "';";
        request.query(query2, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length == 0) {
            let query1 = "SELECT * FROM Stadium WHERE name = '" + stadiumName + "';";
            request.query(query1, function (err, result) {
            if (err) {
              console.log(err);
              sql.close();
            }
            if (result.recordset.length > 0) {
              let query3 = "SELECT * FROM StadiumManager SM INNER JOIN Stadium M ON M.id = SM.stadId WHERE M.name = '" + stadiumName + "';";
              request.query(query3, function (err, result) {
              if (err) {
                console.log(err);
                sql.close();
              }
              if (result.recordset.length == 0) {
                let query = " EXEC addStadiumManager @stadiumManagerName = '" + name + "' ,@stadiumName = '" + stadiumName + "' ,@username = '" + username +"' ,@password = '" + password + "';";
                console.log(query)
                request.query(query, function (err, result) {
                if (err) {
                  console.log(err);
                  sql.close();
                }
                alert('You are registered successfully!');
                res.redirect('/StadiumManagerLog');
                sql.close();
                });
              }
              else{
                alert('There is already a stadium manager for this stadium! ');
                sql.close();
              }
              });
            }
            else{
              alert('This stadium does not exist!');
              sql.close();
            }
            });
          }
          else {
            alert('This username is already registered!');
            sql.close();
          }
        });
      }
      else{
        alert('Please enter all information!');
        sql.close();
      }
  });
});

app.post('/SportsAssociationManagerReg', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  var name = req.body.name;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (username && password && name) {
        let query2 = "SELECT * FROM SystemUser WHERE username = '" + username + "';";
        request.query(query2, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length == 0) {
            let query = " EXEC addAssociationManager @name = '" + name + "' ,@username = '" + username +"' ,@password = '" + password + "';";
            console.log(query)
            request.query(query, function (err, result) {
            if (err) {
                console.log(err);
                sql.close();
            }
            alert('You are registered successfully!');
            res.redirect('/SportsAssociationManagerLog');
            sql.close();
            });
          }
          else{
            alert('This username is already registered!');
            sql.close();
          }
        });
      }
      else {
        alert('Please enter all the information!');
        sql.close();
      }
  });
});

app.post('/ClubRepresentativeReg', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  var name = req.body.name;
  var clubName = req.body.clubName;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (username && password && name && clubName) {
        let query3 = "SELECT * FROM SystemUser WHERE username = '" + username + "';";
        request.query(query3, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length == 0) {
            let query1 = "SELECT * FROM Club WHERE name = '" + clubName + "';";
            request.query(query1, function (err, result) {
            if (err) {
              console.log(err);
              sql.close();
            }
            if (result.recordset.length > 0) {
              let query2 = "SELECT * FROM ClubRepresentative CR INNER JOIN Club C ON C.id = CR.clubId WHERE C.name = '" + clubName + "';";
              request.query(query2, function (err, result) {
              if (err) {
                  console.log(err);
                  sql.close();
              }
              if (result.recordset.length == 0) {
                let query = " EXEC addRepresentative @representativeName = '" + name + "' ,@clubName = '"+ clubName + "' ,@representativeUsername = '" + username +"' ,@representativePassword = '" + password + "';";
                console.log(query)
                request.query(query, function (err, result) {
                if (err) {
                console.log(err);
                sql.close();
                }
                alert('You are registered successfully!');
                res.redirect('/ClubRepresentativeLog');
                sql.close();
                });
              }
              else{
                alert('There is already a club representative for this club!');
                sql.close();
              }
              });
            }
            else{
              alert('This Club does not exist! ');
              sql.close();
            }
            });
          }
          else{
            alert('This username is already registered!');
            sql.close();
          }
          });
        }
        else {
            alert('Please enter all the information!');
            sql.close();
        }
  });
});

app.post('/FanReg', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  var name = req.body.name;
  var nationalId = req.body.nationalId;
  var birthdate = req.body.birthdate;
  var address = req.body.address;
  var phoneNumber = req.body.phoneNumber;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (username && password && name && nationalId && birthdate && address && phoneNumber) {
        let query3 = "SELECT * FROM SystemUser WHERE username = '" + username + "';";
        request.query(query3, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length == 0) {
            let query1 = "SELECT * FROM allFans WHERE nationalId = '" + nationalId + "';";
            request.query(query1, function (err, result) {
              if (err) {
                  console.log(err);
                  sql.close();
              }
              if (result.recordset.length == 0) {
            let query = " EXEC addFan @fanName = '" + name + "' ,@username = '" + username +"' ,@password = '" + password + "' ,@nationalId = '" + nationalId + "' ,@birthDate = '" + birthdate + "' ,@address = '" + address + "' ,@phoneNumber = '" + phoneNumber + "';";
            console.log(query)
            request.query(query, function (err, result) {
            if (err) {
              console.log(err);
              sql.close();
            }
            alert('You are registered successfully!');
            res.redirect('/FanLog');
            sql.close();
            });
          }
            else{
              alert('Invalid national Id, it is already registered!');
              sql.close();
            }
          });}
          else{
            alert('This username is already registered!');
            sql.close();
          }
        });
      }
      else {
        alert('Please enter all the information!');
        sql.close();
      }
  });
});

/*app.post('/SystemAdminReg', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  var name = req.body.name;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (username && password && name) {
      let query = " INSERT INTO SystemUser VALUES('" + username + "','" + password + "'); INSERT INTO SystemAdmin VALUES ('" + name + "','" + username + "');";
      console.log(query)
      request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          res.redirect('/SystemAdminLog');
          sql.close();
      });
    } else {
      alert('Please enter all the information!');
    };
  });
});*/

app.post('/addNewClub', function (req, res) {
  var newClubName = req.body.newClubName;
  var newClubLocation = req.body.newClubLocation;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (newClubLocation && newClubName) {
        let query1 = "SELECT * FROM Club WHERE name = '" + newClubName + "';";
        request.query(query1, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length == 0) {
      let query = " EXEC addClub @clubName = '" + newClubName + "' ,@clubLocation = '" + newClubLocation +"' ;";
      console.log(query)
      request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          alert('Club added successfully!');
          sql.close();
      });
    }
    else{
      alert('This Club already exists, choose another name! ');
      sql.close();
    }
    });
    } else {
      alert('Please enter all the information!');
      sql.close();
    }
  });
});

app.post('/deleteClub', function (req, res) {
  var deleteClubName = req.body.deleteClubName;
  
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (deleteClubName) {
        
      let query = " SELECT * FROM Club WHERE name = '" + deleteClubName + "' ;";
      request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length > 0) {
            let query2 = " EXEC deleteClub @clubName = '" + deleteClubName + "' ;";
            console.log(query2)
            request.query(query2, function (err, result) {
                if (err) {
                    console.log(err);
                    sql.close();
                }
                alert('Club deleted successfully!');
                sql.close();
            });
          }
          else{
            alert('This Club does not exist! ');
            sql.close();
          }
          });
      } else {
      alert('Please enter all the information! ');
      sql.close();
    }
  });
});

app.post('/addStadium', function (req, res) {
  var newStadiumName = req.body.newStadiumName;
  var newStadiumLocation = req.body.newStadiumLocation;
  var newStadiumCapacity = req.body.newStadiumCapacity;
  
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (newStadiumName && newStadiumLocation && newStadiumCapacity) {
        let query1 = "SELECT * FROM Stadium WHERE name = '" + newStadiumName + "';";
        request.query(query1, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length == 0) {
      let query = " EXEC addStadium @stadiumName = '" + newStadiumName + "' ,@stadiumLocation = '" + newStadiumLocation + "' ,@stadiumCapacity = '" + newStadiumCapacity +"' ;";
      console.log(query)
      request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          alert('Stadium added successfully!');
          sql.close();
      });
    }
    else{
      alert('This Stadium already exists, choose another name! ');
      sql.close();
    }
    });
    } else {
      alert('Please enter all the information!');
      sql.close();
    }
  });
});

app.post('/deleteStadium', function (req, res) {
  var deleteStadiumName = req.body.deleteStadiumName;
  
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (deleteStadiumName) {
      let query1 = "SELECT * FROM Stadium WHERE name = '" + deleteStadiumName + "';";
      request.query(query1, function (err, result) {
        if (err) {
            console.log(err);
            sql.close();
        }
        if (result.recordset.length > 0) {
          let query2 = " EXEC deleteStadium @stadiumName = '" + deleteStadiumName + "' ;";
          console.log(query2)
          request.query(query2, function (err, result) {
              if (err) {
                  console.log(err);
                  sql.close();
              }
              alert('Stadium deleted successfully!');
              sql.close();
          });
        }
        else{
          alert('This Stadium does not exist! ');
          sql.close();
        }
        });
    } else {
      alert('Please enter all the information!');
      sql.close();
    }
  });
});

app.post('/blockFan', function (req, res) {
  var blockFanNatId = req.body.blockFanNatId;
  
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (blockFanNatId) {
        let query1 = " SELECT * FROM Fan WHERE nationalId = '" + blockFanNatId + "' ;";
        request.query(query1, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length > 0) {
            let query2 = " EXEC blockFan @fanNationalId = '" + blockFanNatId + "' ;";
            console.log(query2)
            request.query(query2, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          alert('Fan Blocked! ');
          sql.close();});
        }
    else{
      alert('This Fan does not exist! ');
      sql.close();
    }
    });
    } else {
      alert('Please enter all the information!');
      sql.close();
    }
  });
});

app.post('/addMatch', function (req, res) {
  var newHostClubName = req.body.newHostClubName;
  var newGuestClubName = req.body.newGuestClubName;
  var newMatchStartTime = req.body.newMatchStartTime;
  var newMatchEndTime = req.body.newMatchEndTime;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (newHostClubName && newGuestClubName && newMatchStartTime && newMatchEndTime) {
        let query1 = "SELECT * FROM Club WHERE name = '" + newHostClubName + "';";
        let query2 = "SELECT * FROM Club WHERE name = '" + newGuestClubName + "';";
        request.query(query1, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length == 0) {
            alert('Host club does not exist!');
            sql.close();
          }
          else{
            request.query(query2, function (err, result) {
              if (err) {
                  console.log(err);
                  sql.close();
              }
              if (result.recordset.length == 0) {
                alert('Guest club does not exist!');
                sql.close();
              }
              else{
                if(newHostClubName == newGuestClubName){
                  alert('Host club and guest club can not be the same club!');
                  sql.close();
                }
                else{
                  let query3 = "SELECT * FROM allMatches WHERE ((hostClub = '" + newHostClubName + "' OR guestClub = '" + newGuestClubName + "' ) OR (hostClub = '" 
                  + newGuestClubName + "' OR guestClub = '" + newHostClubName +"')) AND (start_time = '" + newMatchStartTime + "');"; 
                  request.query(query3, function (err, result) {
                  if (err) {
                  console.log(err);
                  sql.close();
                  }
                  if (result.recordset.length == 0) {
                let query = " EXEC addNewMatch @hostClubName = '" + newHostClubName + "' ,@guestClubName = '" + newGuestClubName + "' ,@start_time = '" + newMatchStartTime + "' ,@end_time = '" + newMatchEndTime +"' ;";
                console.log(query);
                request.query(query, function (err, result) {
                if (err) {
                    console.log(err);
                    sql.close();
                }
                alert('Match added successfully!');
                sql.close();
                  });
              }
              else{
                alert('These clubs have already a scheduled match on the same date!');
                sql.close();
              }
            });
          }}
            });
          }
        });
    } else {
      alert('Please enter all the information!');
      sql.close();
    }
  });
});

app.post('/deleteMatch', function (req, res) {
  var deleteHostClubName = req.body.deleteHostClubName;
  var deleteGuestClubName = req.body.deleteGuestClubName;
  var deleteMatchStartTime = req.body.deleteMatchStartTime;
  var deleteMatchEndTime = req.body.deleteMatchEndTime;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object  
      var request = new sql.Request();
      // query to the database and execute procedure
      if (deleteHostClubName && deleteGuestClubName && deleteMatchStartTime && deleteMatchEndTime) {
      let query1 = " SELECT * FROM allMatchesWithTime WHERE hostClub = '" + deleteHostClubName + "' AND guestClub = '" + deleteGuestClubName + "'AND start_time = '" + deleteMatchStartTime + "'AND end_time = '" + deleteMatchEndTime + "' ;";
      request.query(query1, function (err, result) {
        if (err) {
            console.log(err);
            sql.close();
        }
        if (result.recordset.length > 0) {
      let query2 = " EXEC deleteMatchByDate @hostClubName = '" + deleteHostClubName + "' ,@guestClubName = '" + deleteGuestClubName + "',@start_time = '" + deleteMatchStartTime + "',@end_time = '" + deleteMatchEndTime + "' ;";
      console.log(query2)
      request.query(query2, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          alert('Match deleted successfully!');
          sql.close();
      });}
      else{
        alert('This Match does not exist! ');
        sql.close();
      }
      });
    } else {
      alert('Please enter all the information!');
      sql.close();
    }
  });
});


app.post('/addHostRequest', function (req, res) {
  var clubName = req.body.clubName;
  var stadiumToBeHosted = req.body.stadiumToBeHosted;
  var matchStartTime = req.body.matchStartTime;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (clubName && stadiumToBeHosted && matchStartTime) {
      let query1 = "SELECT * FROM Club WHERE name = '" + clubName + "';";
      request.query(query1, function (err, result) {
        if (err) {
            console.log(err);
            sql.close();
        }
        if (result.recordset.length == 0) {
          alert('This club does not exist! ');
          sql.close();
        }
        else{
          let query2 = "SELECT * FROM Stadium WHERE name = '" + stadiumToBeHosted + "';";
      request.query(query2, function (err, result) {
        if (err) {
            console.log(err);
            sql.close();
        }
        if (result.recordset.length == 0) {
          alert('This stadium does not exist! ');
          sql.close();
        }
        else{
          let query3 = "SELECT * FROM Match M INNER JOIN Club C ON C.id = M.hostClubId WHERE M.start_time = '" + matchStartTime + "' AND C.name = '" + clubName + "';"
          request.query(query3, function (err, result) {
            if (err) {
                console.log(err);
                sql.close();
            }
            if (result.recordset.length == 0) {
              alert('This match does not exist! ');
              sql.close();
            }
            else{
              let query4 = "SELECT * FROM HostRequest HR " + 
              "INNER JOIN ClubRepresentative CR ON CR.id = HR.clubRepId " +
              "INNER JOIN Club C ON C.id = CR.clubId " +
              "INNER JOIN StadiumManager SM ON SM.id = HR.stadManId "+
              "INNER JOIN Stadium S ON S.id = SM.stadId " +
              "INNER JOIN Match M ON M.id = HR.matchId " +
              "WHERE HR.status = 'unhandled' AND C.name = '" + clubName + "' AND S.name = '" + stadiumToBeHosted + "' AND M.start_time = '" + matchStartTime + "';";
              request.query(query4, function (err, result) {
                if (err) {
                    console.log(err);
                    sql.close();
                }
                if (result.recordset.length > 0) {
                  alert('This request is already sent! ');
                  sql.close();
                }
                else{
                  let query = " EXEC addHostRequest @clubName = '" + clubName + "' ,@stadiumName = '" + stadiumToBeHosted + "' ,@start_time = '" + matchStartTime +"' ;";
                  console.log(query)
                  request.query(query, function (err, result) {
                  if (err) {
                      console.log(err);
                      sql.close();
                  }
                  alert('Request sent successfully!');
                  sql.close();
                  });
                }
              });
            }
          });        
        }
          });
        }
         });
        }
        else {
          alert('Please enter all the information!');
          sql.close();
    };
  });
});

app.post('/acceptRequest', function (req, res) {
  var SMusername = req.body.SMusername;
  var hostClubName = req.body.hostClubName;
  var guestClubName = req.body.guestClubName;
  var startTime = req.body.startTime;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (SMusername && hostClubName && guestClubName && startTime) {
        let query = "SELECT * FROM Match M " + 
        "INNER JOIN HostRequest HR ON HR.matchId = M.id " + 
        "INNER JOIN StadiumManager SM ON SM.id = HR.stadManId " +
        "INNER JOIN Club C1 ON C1.id = M.hostClubId " + 
        "INNER JOIN Club C2 ON C2.id = M.guestClubId " +
        "INNER JOIN ClubRepresentative CR ON CR.clubId = C1.id " + 
        "WHERE HR.status = 'unhandled' AND SM.username = '" + SMusername + "' AND C1.name = '" + hostClubName + "' AND C2.name = '" + guestClubName + "' AND M.start_time = '" + startTime + "' ;";

        request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length > 0) {
            let query2 = "SELECT * FROM Match M " + 
        "INNER JOIN HostRequest HR ON HR.matchId = M.id " + 
        "INNER JOIN StadiumManager SM ON SM.id = HR.stadManId " +
        "INNER JOIN Club C1 ON C1.id = M.hostClubId " + 
        "INNER JOIN Club C2 ON C2.id = M.guestClubId " +
        "INNER JOIN ClubRepresentative CR ON CR.clubId = C1.id " + 
        "WHERE HR.status = 'accepted' AND SM.username = '" + SMusername + "' AND M.start_time = '" + startTime + "' ;";

        request.query(query2, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length == 0) {

      let query1 = " EXEC acceptRequest @stadiumManagerUsername = '" + SMusername + "' ,@hostClubName = '" + hostClubName + "' ,@guestClubName = '" + guestClubName + "' ,@startTime = '" + startTime +"' ;";
      console.log(query1)
      request.query(query1, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          alert('Request accepted successfully!');
          sql.close();
      });
    }
    else{
      alert('There is a scheduled match on that stadium at the same time!');
      sql.close();
    }
  });}
    else{
      alert('This request does not exist! ');
      sql.close();
    }
    });
    } else {
      alert('Please enter all the information!');
      sql.close();
    };
  });
});

app.post('/rejectRequest', function (req, res) {
  var SMusername = req.body.SMusername;
  var hostClubName = req.body.hostClubName;
  var guestClubName = req.body.guestClubName;
  var startTime = req.body.startTime;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (SMusername && hostClubName && guestClubName && startTime) {
        let query = "SELECT * FROM Match M " + 
        "INNER JOIN HostRequest HR ON HR.matchId = M.id " + 
        "INNER JOIN StadiumManager SM ON SM.id = HR.stadManId " +
        "INNER JOIN Club C1 ON C1.id = M.hostClubId " + 
        "INNER JOIN Club C2 ON C2.id = M.guestClubId " +
        "INNER JOIN ClubRepresentative CR ON CR.clubId = C1.id " + 
        "WHERE HR.status = 'unhandled' AND SM.username = '" + SMusername + "' AND C1.name = '" + hostClubName + "' AND C2.name = '" + guestClubName + "' AND M.start_time = '" + startTime + "' ;";

        request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length > 0) {
        let query1 = " EXEC rejectRequest @stadiumManagerUsername = '" + SMusername + "' ,@hostClubName = '" + hostClubName + "' ,@guestClubName = '" + guestClubName + "' ,@startTime = '" + startTime +"' ;";
      console.log(query1)
      request.query(query1, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          alert('Request rejected Successfully!');
          sql.close();
      });
    }
    else{
      alert('This request does not exist! ');
      sql.close();
    }
    });
    } else {
      alert('Please enter all the information!');
      sql.close();
    };
  });
});

app.post('/purchaseTicket', function (req, res) {
  var nationalId = req.body.nationalId;
  var hostClubName = req.body.hostClubName;
  var guestClubName = req.body.guestClubName;
  var startTime = req.body.startTime;
  
  sql.connect(config, function (err) {
      if (err) console.log(err);
      // create Request object
      var request = new sql.Request();
      // query to the database and execute procedure
      if (nationalId && hostClubName && guestClubName && startTime) {
        let query1 = "SELECT * FROM Ticket T " + 
        "INNER JOIN Match M ON M.id = T.matchId " + 
        "INNER JOIN Club C1 ON C1.id = M.hostClubId " + 
        "INNER JOIN Club C2 ON C2.id = M.guestClubId WHERE T.status = '1' AND C1.name = '" + hostClubName + "' AND C2.name = '" + guestClubName + "' AND M.start_time = '" + startTime + "' ;";
        request.query(query1, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          if (result.recordset.length > 0) {
      let query = " EXEC purchaseTicket @fanNationalId = '" + nationalId + "' ,@hostClubName = '" + hostClubName + "' ,@guestClubName = '" + guestClubName + "' ,@start_time = '" + startTime +"' ;";
      console.log(query)
      request.query(query, function (err, result) {
          if (err) {
              console.log(err);
              sql.close();
          }
          alert('Ticket purchased successfully!');
          sql.close();
      });
    }
    else{
      alert('This ticket does not exist! ');
      sql.close();
    }
    });
    } else {
      alert('Please enter all the information!');
      sql.close();
    };
  });
});

app.listen(3000);