var express = require('express');
var path = require('path');
var fs = require('fs');
var app = express();
var sql = require('mssql/msnodesqlv8');
const { query } = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
var alert = require('alert');

// database configuration
var config={
  database: 'Milestone2',
  server: 'JOY-LENOVO\\SQLEXPRESS',
  driver: 'msnodesqlv8',
  options:{
    trustedConnection:true
  }
};


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));

app.get('/account', function(req, res){
  res.render('account')
});

app.get('/admin', function(req, res){
  res.render('admin')
});

app.get('/apply-certificate', function(req, res){
  res.render('apply-certificate')
});

app.get('/apply-cheque', function(req, res){
  res.render('apply-cheque')
});

app.get('/apply-credit-card', function(req, res){
  res.render('apply-credit-card')
});

app.get('/apply-for-a-card', function(req, res){
  res.render('apply-for-a-card')
});

app.get('/apply-loan', function(req, res){
  res.render('apply-loan')
});

app.get('/banker', function(req, res){
  res.render('banker')
});

app.get('/donate', function(req, res){
  res.render('donate')
});

app.get('/edit-info', function(req, res){
  res.render('edit-info')
});

app.get('/home', function(req, res){
  res.render('home')
});

app.get('/login', function(req, res){
  res.render('login')
});

app.get('/notifications', function(req, res){
  res.render('notifications')
});

app.get('/open-account', function(req, res){
  res.render('open-account')
});

app.get('/pay-electricity', function(req, res){
  res.render('pay-electricity')
});

app.get('/pay-gas', function(req, res){
  res.render('pay-gas')
});

app.get('/pay-telecom', function(req, res){
  res.render('pay-telecom')
});

app.get('/pay-water', function(req, res){
  res.render('pay-water')
});

app.get('/profile', function(req, res){
  res.render('profile')
});

app.get('/register', function(req, res){
  res.render('register')
});

app.get('/report', function(req, res){
  res.render('report')
});

app.get('/set-reminder', function(req, res){
  res.render('set-reminder')
});

app.get('/transfer-domestic', function(req, res){
  res.render('transfer-domestic')
});

app.get('/transfer-internal', function(req, res){
  res.render('transfer-internal')
});

app.get('/transfer-international', function(req, res){
  res.render('transfer-international')
});

app.get('/view-account-transactions', function(req, res){
  res.render('view-account-transactions')
});

app.get('/view-card-transactions', function(req, res){
  res.render('view-card-transactions')
});

app.get('/view-certificates', function(req, res){
  res.render('view-certificates')
});

app.get('/view-cheques', function(req, res){
  res.render('view-cheques')
});

app.get('/view-credit-card', function(req, res){
  res.render('view-credit-card')
});

app.get('/view-loans', function(req, res){
  res.render('view-loans')
});


app.post('/login', async function (req, res) {
  var username = req.body.user;
  var password = req.body.pass;
  if (username == "" || password == "") {
      let alert = require('alert');
      alert('please enter your username and your password :)');        
  }
  else{
      if (username == "admin" && password == "admin") {
      res.render("admin");      
    }
    else{
      if (username == "banker" && password == "banker") {
        res.render("banker");  
    }
    else{
      if (username == "user" && password == "user") {
        res.render("home");  
    }
    else{
      let alert = require('alert');
      alert('Wrong username or password :)');}
  }}}
});


app.listen(3000);